=== worksai-linkengine ===
Requires PHP: 8.1
License: MIT

Upload `worksai-linkengine.zip` in WordPress Admin -> Plugins -> Add New -> Upload Plugin, or require `worksai-linkengine-wp-bridge.php` in PHP 8.2+.
